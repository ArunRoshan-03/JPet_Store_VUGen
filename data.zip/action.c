Action()
{

	web_url("canonical.html", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/success.txt?ipv4", "Referer=", ENDITEM, 
		"Url=https://content-signature-2.cdn.mozilla.net/chains/remote-settings.content-signature.mozilla.org-2023-09-19-11-14-05.chain", "Referer=", ENDITEM, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$ct=application/x-protobuf&key=AIzaSyC7jsptDS3am4tPx4r3nxis7IMjBc5Dovo&$httpMethod=POST&$req=ChUKE25hdmNsaWVudC1hdXRvLWZmb3gaJwgFEAEaGwoNCAUQBhgBIgMwMDEwARCWoRIaAhgFQ14N3CICIAIoARonCAEQARobCg0IARAGGAEiAzAwMTABEPfsDBoCGAXQXw7TIgIgAigBGicIAxABGhsKDQgDEAYYASIDMDAxMAEQtOMMGgIYBeoI8DQiAiACKAEaJwgHEAEaGwoNCAcQBhgBIgMwMDEwARD5sg0aAhgFHUyTMCICIAIoARolCAkQARoZCg0ICRAGGAEiAzAwMTABECEaAhgFRMpiUiICIAIoAQ==", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_custom_request("r3.o.lencr.org", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\xAD\no9\\xA9\\xEBP?5\\x9Ep\\xB8Jxr=\\x1B", 
		LAST);

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("tiles", 
		"URL=https://contile.services.mozilla.com/v1/tiles", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org_2", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\xAD\no9\\xA9\\xEBP?5\\x9Ep\\xB8Jxr=\\x1B", 
		LAST);

	web_custom_request("gts1c3", 
		"URL=http://ocsp.pki.goog/gts1c3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x11\\x00\\xC6\\x10\\x17p\\x16\\x99\\x10\\xB1\n\\x95$N\\xC1\\xEE\\x98\\xFF", 
		LAST);

	web_custom_request("r3.o.lencr.org_3", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04y\\xC8\\x98Q\\xA0\\xD9n\\x12Wa\n\\xFF{\\xBA^\\xD7U", 
		LAST);

	web_custom_request("r3.o.lencr.org_4", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x047\\xBB\\x9F\\xB5\\x82\\xC5\\x06>=\\x94K\\x0E\\x8E\\xFA%\\xFE\\xFB", 
		LAST);

	web_custom_request("r3.o.lencr.org_5", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\xF8\\x1A$\\xCC+P\\x86\\xEF\\x03R\\xE3=\\x03\\x14\\xA2\\x17P", 
		LAST);

	web_custom_request("r3.o.lencr.org_6", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x040J\\xC5\\x03\\xDE\r\\xD0s6\\x9E\\xF3\\x11k\\xBF7\\xF5<", 
		LAST);

	lr_think_time(4);

	web_custom_request("ocsp.digicert.com", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x06\\xC8\\x03s\\xB9\\x06C\\xF6\\x1E\\xA1`\\xE2\\xBE}\\x03\\x00", 
		LAST);

	web_custom_request("ocsp.digicert.com_2", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x06'd\\xBD\\xAC\\x97O,\nP\\xA8l\\xF3\\xF9\\x00\\xA6", 
		LAST);

	web_custom_request("r3.o.lencr.org_7", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\xC5\\xB5l9\ry\\xB2\\xB1\\x08\\xDAEz\\xE7\\xBE\\xA3\\x0E\\xF8", 
		LAST);

	web_url("recommendations", 
		"URL=https://firefox-api-proxy.cdn.mozilla.net/desktop/v1/recommendations?locale=en-US&region=IN&count=30", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("cfr-v1-en-US", 
		"URL=https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/ms-language-packs/records/cfr-v1-en-US", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("_ga_MQ7767QQQW=GS1.1.1692364627.1.0.1692364635.0.0.0; DOMAIN=aus5.mozilla.org");

	web_add_cookie("_ga=GA1.2.907056927.1692364628; DOMAIN=aus5.mozilla.org");

	web_url("update.xml", 
		"URL=https://aus5.mozilla.org/update/6/Firefox/116.0.3/20230815173142/WINNT_x86_64-msvc-x64/en-US/release/Windows_NT%2010.0.0.0.19045.2364%20(x64)/ISET:SSE4_2,MEM:7847/default/default/update.xml?force=1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("cfr-v1-en-US_2", 
		"URL=https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/ms-language-packs/records/cfr-v1-en-US", 
		"Method=GET", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_connect("ID=0", 
		"URI=wss://push.services.mozilla.com/", 
		"Origin=wss://push.services.mozilla.com/", 
		"SecWebSocketExtensions=permessage-deflate", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_custom_request("8afbd4cd-f3aa-4394-ae7a-3d88ccb79e27", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/8afbd4cd-f3aa-4394-ae7a-3d88ccb79e27", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":271,\"start_time\":\"2023-08-21T15:50+05:30\",\"end_time\":\"2023-08-21T16:02+05:30\",\"reason\":\"newtab_session_end\",\"experiments\":{\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\",\"extra\":{\"enrollmentId\":\"4634dde7-98c7-40ea-949f-3c908ee20795\",\"type\":\"nimbus-nimbus\"}},\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\""
		"enrollmentId\":\"4331d05f-bced-426c-98ba-bc7b8d870645\"}},\"serp-ad-telemetry-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"eb23cd2e-978a-4755-a72b-d39611a48817\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"17e05982-916d-4ef0-a037-74d595cf0228\"}},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\",\""
		"enrollmentId\":\"e45cf317-62c4-4684-ad82-39e142973108\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"first_run_date\":\"2022-12-02+05:30\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"architecture\":\"x86_64\",\"app_channel\":\"release\",\"app_build\":\"20230815173142\",\"app_display_version\":\"116.0.3\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"windows_build_number\":19045,\"client_id\":\"ac18ee09-27b6-4d69-b120-39af32374c86\"},\"metrics\":{\"boolean\":{\"pocket.is_signed_in\""
		":false,\"topsites.enabled\":true,\"newtab.search.enabled\":true,\"pocket.sponsored_stories_enabled\":true,\"pocket.enabled\":true,\"topsites.sponsored_enabled\":true},\"string_list\":{\"newtab.blocked_sponsors\":[]},\"quantity\":{\"topsites.rows\":1},\"string\":{\"newtab.locale\":\"en-US\",\"search.engine.default.engine_id\":\"google-b-d\",\"newtab.homepage_category\":\"enabled\",\"search.engine.private.engine_id\":\"\",\"newtab.newtab_category\":\"enabled\"},\"uuid\":{\""
		"legacy.telemetry.client_id\":\"eae14f16-8932-4a97-8ada-7cd07ba522fd\"}},\"events\":[{\"timestamp\":0,\"category\":\"newtab\",\"name\":\"opened\",\"extra\":{\"source\":\"about:home\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":0,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"is_sponsored\":\"false\",\"position\":\"0\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":1,\"category\":\"topsites\",\"name\":\"impression\""
		",\"extra\":{\"is_sponsored\":\"false\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"position\":\"1\"}},{\"timestamp\":1,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"position\":\"2\",\"is_sponsored\":\"false\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":1,\"category\":\"pocket\",\"name\":\"impression\",\"extra\":{\"is_sponsored\":\"false\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"position\":\"2\"}},{\""
		"timestamp\":2,\"category\":\"pocket\",\"name\":\"impression\",\"extra\":{\"position\":\"0\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"is_sponsored\":\"false\"}},{\"timestamp\":3,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"is_sponsored\":\"false\",\"position\":\"5\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":3,\"category\":\"pocket\",\"name\":\"impression\",\"extra\":{\"position\":\"1\",\"is_sponsored\":\"false\",\""
		"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":5,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"is_sponsored\":\"false\",\"position\":\"4\"}},{\"timestamp\":5,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"is_sponsored\":\"false\",\"position\":\"6\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":5,\"category\":\"topsites\",\"name\":\""
		"impression\",\"extra\":{\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"position\":\"3\",\"is_sponsored\":\"false\"}},{\"timestamp\":6,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"position\":\"7\",\"is_sponsored\":\"false\"}},{\"timestamp\":512,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"tile_id\":\"73588\",\"position\":\"1\",\"is_sponsored\":\"true\",\"advertiser_name\":\"trivago\""
		",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":517,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"advertiser_name\":\"amazon\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"is_sponsored\":\"true\",\"position\":\"0\",\"tile_id\":\"74357\"}},{\"timestamp\":367196,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"advertiser_name\":\"trivago\",\"position\":\"1\",\"tile_id\":\"73588\",\"newtab_visit_id\":\""
		"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\",\"is_sponsored\":\"true\"}},{\"timestamp\":367199,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"tile_id\":\"74357\",\"position\":\"0\",\"advertiser_name\":\"amazon\",\"is_sponsored\":\"true\",\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}},{\"timestamp\":701850,\"category\":\"newtab\",\"name\":\"closed\",\"extra\":{\"newtab_visit_id\":\"{4640ea43-cbaa-455d-a1bb-2cd1c6fa2385}\"}}]}", 
		LAST);

	web_custom_request("gts1c3_2", 
		"URL=http://ocsp.pki.goog/gts1c3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\xC7.y\\x8A\\xDD\\xFFa4\\xB3\\xBA\\xEDGB\\xB8\\xBB\\xC6\\xC0$\\x07c\\x04\\x14\\x8At\\x7F\\xAF\\x85\\xCD\\xEE\\x95\\xCD=\\x9C\\xD0\\xE2F\\x14\\xF3q5\\x1D'\\x02\\x11\\x00\\xC6\\x10\\x17p\\x16\\x99\\x10\\xB1\n\\x95$N\\xC1\\xEE\\x98\\xFF", 
		LAST);

	web_custom_request("r3.o.lencr.org_8", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14H\\xDA\\xC9\\xA0\\xFB+\\xD3-O\\xF0\\xDEh\\xD2\\xF5g\\xB75\\xF9\\xB3\\xC4\\x04\\x14\\x14.\\xB3\\x17\\xB7XV\\xCB\\xAEP\t@\\xE6\\x1F\\xAF\\x9D\\x8B\\x14\\xC2\\xC6\\x02\\x12\\x040J\\xC5\\x03\\xDE\r\\xD0s6\\x9E\\xF3\\x11k\\xBF7\\xF5<", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1692608234465\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_url("v1", 
		"URL=https://firefox.settings.services.mozilla.com/v1/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org_9", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14H\\xDA\\xC9\\xA0\\xFB+\\xD3-O\\xF0\\xDEh\\xD2\\xF5g\\xB75\\xF9\\xB3\\xC4\\x04\\x14\\x14.\\xB3\\x17\\xB7XV\\xCB\\xAEP\t@\\xE6\\x1F\\xAF\\x9D\\x8B\\x14\\xC2\\xC6\\x02\\x12\\x03\\xC5\\xB5l9\ry\\xB2\\xB1\\x08\\xDAEz\\xE7\\xBE\\xA3\\x0E\\xF8", 
		LAST);

	web_custom_request("b42573e3-9833-4bbe-ad0d-c66602abda51", 
		"URL=https://incoming.telemetry.mozilla.org/submit/messaging-system/undesired-events/1/b42573e3-9833-4bbe-ad0d-c66602abda51", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t24.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"experiments\":{\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\"},\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\"},\"serp-ad-telemetry-rollout\":{\"branch\":\"control\"},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\"},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\"},\"bug-1848748-pref-page-load-time-patch-release-116-117\":{\"branch\":\"reset-to-false\"}},\""
		"locale\":\"en-US\",\"version\":\"116.0.3\",\"release_channel\":\"release\",\"event\":\"ASR_RS_NO_MESSAGES\",\"message_id\":\"n/a\",\"event_context\":\"whats-new-panel\",\"addon_version\":\"20230815173142\",\"impression_id\":\"{309f36cc-6348-4bb8-9724-81715552739d}\"}", 
		LAST);

	web_custom_request("84ff9c1c-9402-4511-bd22-08224ce77598", 
		"URL=https://incoming.telemetry.mozilla.org/submit/messaging-system/undesired-events/1/84ff9c1c-9402-4511-bd22-08224ce77598", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"experiments\":{\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\"},\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\"},\"serp-ad-telemetry-rollout\":{\"branch\":\"control\"},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\"},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\"},\"bug-1848748-pref-page-load-time-patch-release-116-117\":{\"branch\":\"reset-to-false\"}},\""
		"locale\":\"en-US\",\"version\":\"116.0.3\",\"release_channel\":\"release\",\"event\":\"ASR_RS_NO_MESSAGES\",\"message_id\":\"n/a\",\"event_context\":\"whats-new-panel\",\"addon_version\":\"20230815173142\",\"impression_id\":\"{309f36cc-6348-4bb8-9724-81715552739d}\"}", 
		LAST);

	web_custom_request("144ad8a4-09b4-4c05-a2c1-4b9586f92182", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/144ad8a4-09b4-4c05-a2c1-4b9586f92182", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":272,\"start_time\":\"2023-08-21T16:02+05:30\",\"end_time\":\"2023-08-21T16:02+05:30\",\"reason\":\"newtab_session_end\",\"experiments\":{\"serp-ad-telemetry-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"eb23cd2e-978a-4755-a72b-d39611a48817\"}},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\",\"extra\":{\"enrollmentId\":\"e45cf317-62c4-4684-ad82-39e142973108\",\"type\":\"nimbus-rollout\"}},\""
		"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\",\"extra\":{\"enrollmentId\":\"4634dde7-98c7-40ea-949f-3c908ee20795\",\"type\":\"nimbus-nimbus\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"enrollmentId\":\"17e05982-916d-4ef0-a037-74d595cf0228\",\"type\":\"nimbus-rollout\"}},\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\""
		":\"4331d05f-bced-426c-98ba-bc7b8d870645\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2022-12-02+05:30\",\"app_channel\":\"release\",\"os_version\":\"10.0\",\"app_display_version\":\"116.0.3\",\"app_build\":\"20230815173142\",\"architecture\":\"x86_64\",\"os\":\"Windows\",\"windows_build_number\":19045,\"client_id\":\"ac18ee09-27b6-4d69-b120-39af32374c86\"},\"metrics\":{\"string\":{\"newtab.locale\":\"en-US\",\""
		"search.engine.default.engine_id\":\"google-b-d\",\"search.engine.private.engine_id\":\"\",\"newtab.homepage_category\":\"enabled\",\"newtab.newtab_category\":\"enabled\"},\"quantity\":{\"topsites.rows\":1},\"uuid\":{\"legacy.telemetry.client_id\":\"eae14f16-8932-4a97-8ada-7cd07ba522fd\"},\"boolean\":{\"pocket.sponsored_stories_enabled\":true,\"newtab.search.enabled\":true,\"topsites.sponsored_enabled\":true,\"pocket.enabled\":true,\"pocket.is_signed_in\":false,\"topsites.enabled\":true},\""
		"string_list\":{\"newtab.blocked_sponsors\":[]}},\"events\":[{\"timestamp\":0,\"category\":\"newtab\",\"name\":\"closed\",\"extra\":{\"newtab_visit_id\":\"{5fd80e03-9a74-452b-85a5-50aa824a23e7}\"}}]}", 
		LAST);

	web_custom_request("9a6798fd-c905-4f8c-aae3-d6e8787ddb4c", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/pageload/1/9a6798fd-c905-4f8c-aae3-d6e8787ddb4c", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":50,\"start_time\":\"2023-08-21T15:50+05:30\",\"end_time\":\"2023-08-21T18:48+05:30\",\"reason\":\"startup\"},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"architecture\":\"x86_64\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"app_display_version\":\"116.0.3\",\"app_build\":\"20230815173142\",\"app_channel\":\"release\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2022-12-02+05:30\",\"windows_build_number\":19045},\"events\":[{\"timestamp\""
		":0,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"load_time\":\"1411\",\"load_type\":\"NORMAL\",\"fcp_time\":\"858\",\"response_time\":\"744\",\"dns_lookup_time\":\"98\",\"js_exec_time\":\"72\",\"http_ver\":\"2\"}},{\"timestamp\":4381,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"response_time\":\"1655\",\"http_ver\":\"2\",\"same_origin_nav\":\"false\",\"load_time\":\"1876\",\"dns_lookup_time\":\"91\",\"load_type\":\"STOP\"}},{\"timestamp\":10348,\"category\":\"perf\",\""
		"name\":\"page_load\",\"extra\":{\"same_origin_nav\":\"true\",\"fcp_time\":\"354\",\"load_time\":\"4398\",\"http_ver\":\"2\",\"response_time\":\"311\",\"load_type\":\"LINK\"}},{\"timestamp\":11456,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"fcp_time\":\"247\",\"js_exec_time\":\"0\",\"load_time\":\"251\",\"load_type\":\"LINK\",\"http_ver\":\"2\",\"same_origin_nav\":\"true\",\"response_time\":\"224\"}},{\"timestamp\":22952,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\""
		"same_origin_nav\":\"true\",\"redirect_time\":\"319\",\"fcp_time\":\"500\",\"redirect_count\":\"1\",\"response_time\":\"477\",\"load_type\":\"LINK\",\"http_ver\":\"2\",\"load_time\":\"668\"}}]}", 
		LAST);

	web_custom_request("4fbe9e26-17bf-4694-94e1-4c8eb4966f88", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/4fbe9e26-17bf-4694-94e1-4c8eb4966f88", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":273,\"start_time\":\"2023-08-21T16:02+05:30\",\"end_time\":\"2023-08-21T18:48+05:30\",\"reason\":\"component_init\"},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"app_display_version\":\"116.0.3\",\"os_version\":\"10.0\",\"app_channel\":\"release\",\"architecture\":\"x86_64\",\"app_build\":\"20230815173142\",\"os\":\"Windows\",\"client_id\":\"ac18ee09-27b6-4d69-b120-39af32374c86\",\"first_run_date\":\"2022-12-02+05:30\",\"build_date\":\"1970-01-01T00:00:00+00"
		":00\",\"windows_build_number\":19045},\"metrics\":{\"quantity\":{\"topsites.rows\":1},\"string_list\":{\"newtab.blocked_sponsors\":[]},\"string\":{\"newtab.newtab_category\":\"enabled\",\"newtab.locale\":\"en-US\",\"newtab.homepage_category\":\"enabled\"},\"boolean\":{\"pocket.enabled\":true,\"pocket.is_signed_in\":false,\"topsites.sponsored_enabled\":true,\"pocket.sponsored_stories_enabled\":true,\"topsites.enabled\":true,\"newtab.search.enabled\":true}}}", 
		LAST);

	web_custom_request("c8fdeba1-246d-4562-bd19-811cb781da7b", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/c8fdeba1-246d-4562-bd19-811cb781da7b", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":138,\"start_time\":\"2023-08-21T15:50+05:30\",\"end_time\":\"2023-08-21T18:48+05:30\",\"reason\":\"active\",\"experiments\":{\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"enrollmentId\":\"17e05982-916d-4ef0-a037-74d595cf0228\",\"type\":\"nimbus-rollout\"}},\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-nimbus\",\"enrollmentId\":\""
		"4634dde7-98c7-40ea-949f-3c908ee20795\"}},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"e45cf317-62c4-4684-ad82-39e142973108\"}},\"serp-ad-telemetry-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"eb23cd2e-978a-4755-a72b-d39611a48817\"}},\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\""
		"enrollmentId\":\"4331d05f-bced-426c-98ba-bc7b8d870645\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"client_id\":\"ac18ee09-27b6-4d69-b120-39af32374c86\",\"windows_build_number\":19045,\"first_run_date\":\"2022-12-02+05:30\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"architecture\":\"x86_64\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"app_channel\":\"release\",\"app_build\":\"20230815173142\",\"app_display_version\":\"116.0.3\"},\"metrics\":{\"counter\":{\""
		"browser.engagement.active_ticks\":11,\"browser.engagement.uri_count\":6},\"labeled_counter\":{\"glean.validation.pings_submitted\":{\"baseline\":1,\"events\":1,\"newtab\":3,\"pageload\":1,\"top-sites\":2}},\"uuid\":{\"legacy.telemetry.client_id\":\"eae14f16-8932-4a97-8ada-7cd07ba522fd\"},\"datetime\":{\"glean.validation.first_run_hour\":\"2022-12-02T12+05:30\"}}}", 
		LAST);

	web_custom_request("28a85a67-16c1-481d-a47f-6b4474554d86", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/events/1/28a85a67-16c1-481d-a47f-6b4474554d86", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":61,\"start_time\":\"2023-08-21T15:50+05:30\",\"end_time\":\"2023-08-21T18:48+05:30\",\"reason\":\"startup\",\"experiments\":{\"serp-ad-telemetry-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"eb23cd2e-978a-4755-a72b-d39611a48817\"}},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\",\"extra\":{\"enrollmentId\":\"e45cf317-62c4-4684-ad82-39e142973108\",\"type\":\"nimbus-rollout\"}},\""
		"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"4331d05f-bced-426c-98ba-bc7b8d870645\"}},\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-nimbus\",\"enrollmentId\":\"4634dde7-98c7-40ea-949f-3c908ee20795\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"enrollmentId\":\""
		"17e05982-916d-4ef0-a037-74d595cf0228\",\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"app_display_version\":\"116.0.3\",\"app_build\":\"20230815173142\",\"architecture\":\"x86_64\",\"os_version\":\"10.0\",\"app_channel\":\"release\",\"os\":\"Windows\",\"client_id\":\"ac18ee09-27b6-4d69-b120-39af32374c86\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2022-12-02+05:30\",\"windows_build_number\":19045},\"metrics\":{\"boolean\":{\""
		"urlbar.pref_suggest_topsites\":true},\"uuid\":{\"legacy.telemetry.client_id\":\"eae14f16-8932-4a97-8ada-7cd07ba522fd\"},\"quantity\":{\"urlbar.pref_max_results\":10}},\"events\":[{\"timestamp\":0,\"category\":\"fog.validation\",\"name\":\"validate_early_event\"},{\"timestamp\":2295,\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"reason\":\"invalid-feature\",\"feature\":\"accessibilityCache\",\"experiment\":\"next-generation-accessibility-engine-powering-screen-readers\"}"
		"},{\"timestamp\":2296,\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"experiment\":\"next-generation-accessibility-engine-powering-screen-readers-and-other-ats-copy\",\"feature\":\"accessibilityCache\",\"reason\":\"invalid-feature\"}},{\"timestamp\":676434,\"category\":\"serp\",\"name\":\"impression\",\"extra\":{\"source\":\"urlbar\",\"tagged\":\"true\",\"impression_id\":\"f0fbd9ff-3876-4f0d-b1b4-09c024b5b696\",\"partner_code\":\"firefox-b-d\",\"shopping_tab_displayed\""
		":\"true\",\"provider\":\"google\",\"is_shopping_page\":\"false\"}},{\"timestamp\":677559,\"category\":\"serp\",\"name\":\"ad_impression\",\"extra\":{\"ads_loaded\":\"1\",\"component\":\"shopping_tab\",\"ads_visible\":\"1\",\"ads_hidden\":\"0\",\"impression_id\":\"f0fbd9ff-3876-4f0d-b1b4-09c024b5b696\"}},{\"timestamp\":678952,\"category\":\"serp\",\"name\":\"engagement\",\"extra\":{\"target\":\"non_ads_link\",\"impression_id\":\"f0fbd9ff-3876-4f0d-b1b4-09c024b5b696\",\"action\":\"clicked\"}}]}", 
		LAST);

	web_custom_request("01d61fee-831e-4154-ab1d-3a89b8456424", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/messaging-system/1/01d61fee-831e-4154-ab1d-3a89b8456424", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":250,\"start_time\":\"2023-08-21T15:50+05:30\",\"end_time\":\"2023-08-21T18:48+05:30\",\"experiments\":{\"serp-ad-telemetry-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"eb23cd2e-978a-4755-a72b-d39611a48817\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"17e05982-916d-4ef0-a037-74d595cf0228\"}},\""
		"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-nimbus\",\"enrollmentId\":\"4634dde7-98c7-40ea-949f-3c908ee20795\"}},\"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"e45cf317-62c4-4684-ad82-39e142973108\"}},\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\""
		"enrollmentId\":\"4331d05f-bced-426c-98ba-bc7b8d870645\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"first_run_date\":\"2022-12-02+05:30\",\"app_build\":\"20230815173142\",\"app_display_version\":\"116.0.3\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"architecture\":\"x86_64\",\"app_channel\":\"release\",\"windows_build_number\":19045,\"build_date\":\"1970-01-01T00:00:00+00:00\"},\"metrics\":{\"string\":{\"messaging_system.addon_version\":\"20230815173142\",\"messaging_system.event\""
		":\"ASR_RS_NO_MESSAGES\",\"messaging_system.locale\":\"en-US\",\"messaging_system.ping_type\":\"undesired-events\"},\"text\":{\"messaging_system.message_id\":\"n/a\",\"messaging_system.event_context\":\"\\\"whats-new-panel\\\"\"},\"uuid\":{\"messaging_system.impression_id\":\"309f36cc-6348-4bb8-9724-81715552739d\"}}}", 
		LAST);

	web_custom_request("361df62c-8909-41ce-8477-6fcf6aae13b4", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/messaging-system/1/361df62c-8909-41ce-8477-6fcf6aae13b4", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":251,\"start_time\":\"2023-08-21T18:48+05:30\",\"end_time\":\"2023-08-21T18:48+05:30\",\"experiments\":{\"updated-import-infrequent-rollout-make-yourself-at-home-copy\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\",\"enrollmentId\":\"4331d05f-bced-426c-98ba-bc7b8d870645\"}},\"serp-ad-telemetry-rollout\":{\"branch\":\"control\",\"extra\":{\"enrollmentId\":\"eb23cd2e-978a-4755-a72b-d39611a48817\",\"type\":\"nimbus-rollout\"}},\""
		"pocket-newtab-existing-markets-tier-2-rollout\":{\"branch\":\"rollout\",\"extra\":{\"enrollmentId\":\"e45cf317-62c4-4684-ad82-39e142973108\",\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"enrollmentId\":\"17e05982-916d-4ef0-a037-74d595cf0228\",\"type\":\"nimbus-rollout\"}},\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\":{\"branch\":\"treatment\",\"extra\":{\"enrollmentId\":\"4634dde7-98c7-40ea-949f-3c908ee20795\","
		"\"type\":\"nimbus-nimbus\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"53.0.0\",\"os_version\":\"10.0\",\"os\":\"Windows\",\"app_display_version\":\"116.0.3\",\"app_build\":\"20230815173142\",\"app_channel\":\"release\",\"architecture\":\"x86_64\",\"windows_build_number\":19045,\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2022-12-02+05:30\"},\"metrics\":{\"string\":{\"messaging_system.ping_type\":\"undesired-events\",\"messaging_system.locale\":\"en-US\",\""
		"messaging_system.addon_version\":\"20230815173142\",\"messaging_system.event\":\"ASR_RS_NO_MESSAGES\"},\"text\":{\"messaging_system.message_id\":\"n/a\",\"messaging_system.event_context\":\"\\\"whats-new-panel\\\"\"},\"uuid\":{\"messaging_system.impression_id\":\"309f36cc-6348-4bb8-9724-81715552739d\"}}}", 
		LAST);

	/* click the store */

	lr_think_time(8);

	web_url("Catalog.action", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org_10", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\x11\\x16D\\xD2ER\\x8DF!j\\xBB\\xB9b=\\x1F\\x1C^", 
		LAST);

	web_url("v1_2", 
		"URL=https://normandy.cdn.mozilla.net/api/v1/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org_11", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\x88oF\\x15\\xE3,0\\\\\\x93\\xCF\\x87J\\xF6\\xC4G\\xE9j", 
		LAST);

	web_url("classify_client", 
		"URL=https://classify-client.services.mozilla.com/api/v1/classify_client/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://content-signature-2.cdn.mozilla.net/chains/normandy.content-signature.mozilla.org-2023-09-19-11-14-04.chain?cachebust=2017-06-13-21-06", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(29);

	web_url("canonical.html_2", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/success.txt?ipv4", "Referer=", ENDITEM, 
		LAST);

	/* click on the sign button */

	web_url("Account.action;jsessionid=68E69728E3A59904183BE35084E51DE9", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid=68E69728E3A59904183BE35084E51DE9?signonForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	/* Enter the username and password  */

	lr_think_time(125);

	web_submit_form("Account.action", 
		"Snapshot=t40.inf", 
		ITEMDATA, 
		"Name=username", "Value=20487", ENDITEM, 
		"Name=password", "Value=Atmecs@123", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		LAST);

	lr_think_time(25);

	web_submit_form("Account.action_2", 
		"Snapshot=t41.inf", 
		ITEMDATA, 
		"Name=username", "Value=20487", ENDITEM, 
		"Name=password", "Value=Atmecs@123", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		LAST);

	lr_think_time(22);

	web_submit_form("Account.action_3", 
		"Snapshot=t42.inf", 
		ITEMDATA, 
		"Name=username", "Value=20487", ENDITEM, 
		"Name=password", "Value=Atmecs@123", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		LAST);

	web_submit_form("Account.action_4", 
		"Snapshot=t43.inf", 
		ITEMDATA, 
		"Name=username", "Value=j2ee", ENDITEM, 
		"Name=password", "Value=j2ee", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		LAST);

	lr_think_time(49);

	web_url("tiles_2", 
		"URL=https://contile.services.mozilla.com/v1/tiles", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	/* click on pet */

	lr_think_time(32);

	web_custom_request("r3.o.lencr.org_12", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\xAD\no9\\xA9\\xEBP?5\\x9Ep\\xB8Jxr=\\x1B", 
		LAST);

	web_custom_request("r3.o.lencr.org_13", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\xAD\no9\\xA9\\xEBP?5\\x9Ep\\xB8Jxr=\\x1B", 
		LAST);

	web_url("Catalog.action_2", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=REPTILES", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	/* enter the pet name on the search box */

	lr_think_time(57);

	web_submit_form("Catalog.action_3", 
		"Snapshot=t48.inf", 
		ITEMDATA, 
		"Name=keyword", "Value=Iguana", ENDITEM, 
		"Name=searchProducts", "Value=Search", ENDITEM, 
		LAST);

	return 0;
}